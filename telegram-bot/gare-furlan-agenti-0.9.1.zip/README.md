# 16 · Agenti di Claude Code per fase

Ogni fase della gara ha un agente con il modello fisso (più `prezzi-zanutta` per i prezzi Zanutta): il lavoro d'ordine va su
Haiku, il grosso su Sonnet, il ragionamento su Opus. Così si consumano meno
crediti senza risparmiare dove un errore costa.

Gli agenti stanno nel plugin **gare-furlan-agenti**, salvato nell'account
(Impostazioni › Plugin): valgono su tutti e due i PC. Si usano nella scheda
**Code** dell'app Claude, con la cartella `H:\Il mio Drive\GARE APPALTO Furlan`
aperta, perché lavorano con i percorsi di questa cartella.

| agente | modello | fasi | fa |
|---|---|---|---|
| `gara-archivio` | Haiku | 08, 15 | cartella gara nuova, situazione delle gare, cruscotto, archiviazione |
| `gara-rdo` | Haiku | 05, 10 | RDO, libretti misure, bozze mail, anagrafica fornitori |
| `gara-computo` | Sonnet | 01 | estrazione del computo, proposta Super Capitoli |
| `gara-prezzi` | Sonnet | 03, 04, 11, 13 | APU di routine, compilazione GO, prezzari |
| `prezzi-zanutta` | Sonnet | 11 | prezzi netti da impresa su Zanutta Web (area riservata), solo lettura |
| `gara-offerte-fornitori` | Sonnet | 12, 11 | offerte rientrate, confronto, listino e anagrafica |
| `gara-consegna` | Sonnet | 06 | offerta economica, PDF, lettera, file PriMus (XPWE), pacchetto |
| `gara-quantita` | Opus | 02 | controllo quantità, misure dalle tavole |
| `gara-disegni` | Opus | 02 | legge e misura i disegni DWG/DXF (script e CADCraft), su copie |
| `gara-documenti` | Haiku | 06 | PDF e foto: unire, comprimere, OCR, timbri, pacchetto per il portale |
| `gara-stima` | Opus | 18 | stima da zero: disegno + descrizione, per Super Capitoli, nel GO |
| `gara-crono` | Opus | 19 | cronoprogramma: crono per Super Capitolo, crono di dettaglio per lavorazioni, Gantt da allegare all'offerta |
| `gara-prezzi-complessi` | Opus | 03 | APU nuove, stime di rese e mezzi, OBIETTIVO |
| `gara-controllo-finale` | Opus | 06 | controllo prima dell'invio (anche il file PriMus), verdetto PRONTA / NON PRONTA |

## Il capo: /capo

Il modo più semplice è parlare con il capo. Si scrive `/capo` seguito da cosa
fare e su quale gara, per esempio:

- `/capo Liberty Padova: a che punto siamo e cosa facciamo adesso?`
- `/capo 2026.67 è arrivato il computo, portalo dentro`
- `/capo Baia Trieste: sono rientrate le offerte del ferro`

Il capo legge lo STATO della gara, sceglie la fase e l'agente, chiede prima le
decisioni che spettano a Stanislao (conferma dei Super Capitoli, misura
automatica dalle tavole, quale GO usare), passa il lavoro all'agente con
istruzioni complete, controlla il resoconto e propone il passo successivo.
Non fa da solo il lavoro delle fasi: per questo la conversazione del capo può
stare su Sonnet.

Il capo non è un agente ma la conversazione stessa: così può fare domande, cosa
che gli agenti non possono.

## Usare un agente direttamente

Nella scheda Code, con la cartella aperta, si scrive per esempio:

- «usa l'agente gara-archivio: a che punto sono le gare?»
- «usa gara-rdo per le RDO della 2026.67, i Super Capitoli li ho confermati»
- «gara-controllo-finale sulla 2026.62»

Oppure si scrive @ e si sceglie l'agente dall'elenco, o si chiede il lavoro e
basta: Claude sceglie l'agente dalla descrizione.

## Le regole che valgono per tutti

- Leggono la skill `offerta-appalto-furlan` (o la copia in questa cartella) e il
  file della loro fase.
- Non possono fare domande: quello che decide Stanislao (celle gialle, conferma
  dei Super Capitoli, modifiche ai master, spostare cartelle) lo mettono in
  «Da decidere» e si fermano. Le conferme si danno nel messaggio che affida il
  lavoro («i Super Capitoli li ho confermati»).
- A fine lavoro aggiornano `STATO_<commessa>.md` e chiudono con Fatto · File ·
  Punti aperti · Da decidere.
- Le modifiche al GO master non sono di nessun agente: si fanno nella
  conversazione principale, con Opus, dopo la conferma di Stanislao.

Per cambiare il modello di un agente si cambia la riga `model:` del suo file
(`haiku`, `sonnet`, `opus`) e si salva di nuovo il plugin.

## Zanutta Web

`prezzi-zanutta` lavora nel browser di Claude della scheda Code, dove Stanislao è
loggato su `web.zanuttaspa.it/area` (con «Ricorda l'accesso»). La password la
inserisce solo lui; l'agente legge e basta: mai carrello né ordini. La prima
volta descrive com'è fatta l'area in `17_zanutta.md` (ricerca, sconto, netto,
download del listino) e da lì in poi segue quel file.

## Lezioni apprese (dalla 0.8.0)

Gli agenti non hanno memoria propria. Ogni agente legge `_MASTER/METODO_GO/lezioni/lezioni_<agente>.md` a inizio lavoro e a fine lavoro propone (max 3 righe) nuove lezioni; le conferma Stanislao e le scrive il capo. Il capo legge `_MASTER/METODO_GO/MEMORIA_CAPO.md` (memoria condivisa fra i due PC).
